import { useState } from "react";

const FaqPage = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      question: "What is this platform?",
      answer: "This is an AI-powered tool to ask questions, manage tasks, and summarize content.",
    },
    {
      question: "Is it free to use?",
      answer: "Currently yes. Future versions may include premium features.",
    },
    {
      question: "How does summarization work?",
      answer: "It uses AI to condense long text into short summaries.",
    },
    {
      question: "Can I save my tasks?",
      answer: "Yes, tasks can be stored locally or connected to a backend.",
    },
  ];

  const toggle = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen p-6 md:p-10 bg-gray-50">
      <h1 className="text-2xl md:text-3xl font-semibold mb-6">
        Help & FAQ
      </h1>

      <div className="bg-white p-6 rounded-xl shadow-sm space-y-4">
        {faqs.map((item, i) => (
          <div key={i} className="border-b pb-3">
            
            <button
              onClick={() => toggle(i)}
              className="w-full text-left font-medium flex justify-between"
            >
              {item.question}
              <span>{openIndex === i ? "-" : "+"}</span>
            </button>

            {openIndex === i && (
              <p className="mt-2 text-sm text-gray-600">
                {item.answer}
              </p>
            )}

          </div>
        ))}
      </div>
    </div>
  );
};

export default FaqPage;