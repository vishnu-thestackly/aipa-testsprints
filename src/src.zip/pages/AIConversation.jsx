import { useNavigate } from "react-router-dom";
import React, { useState, useRef, useEffect } from "react";
import dayjs from "dayjs";
import { askAI } from "../utils/askAI";

import Button from "../components/conversationpage/Button";
import Card from "../components/conversationpage/Card";

import Arrow from "../assets/images/Arrow.png";
import EnterFrame from "../assets/images/EnterFrame.png";
import Audio from "../assets/images/Audio.png";
import FileUpload from "../assets/images/FileUpload.png";
import AiImage from "../assets/images/AiImage.png";
import Copy from '../assets/images/Copy.png';
import Edit from '../assets/images/Edit.png';
import Save from '../assets/images/Save.png';
import Share from '../assets/images/Share.png';
import SpeakerHigh from '../assets/images/SpeakerHigh.png'
import UserHead from "../assets/images/UserHead.png";
import UserBody from "../assets/images/UserBody.png";
import BackGrounImage from "../assets/images/BackGrounImage.png";

const AIConversation = () => {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const bottomRef = useRef(null);
  

  // auto scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = {
      type: "user",
      text: input,
      time: dayjs().format("hh:mm A"),
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      const res = await askAI(input);

      const botMsg = {
        type: "bot",
        text: res.answer,
        data: res.data,
        time: res.time,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
    }

    setInput("");
  };

  return (
    <div className="relative w-full h-screen overflow-hidden">
      {/* Background */}
      <img
        src={BackGrounImage}
        className="absolute inset-0 w-full h-full object-cover -z-10"
      />

      <div className="flex flex-col items-center gap-6 pt-6">
        {/* Navbar */}
        <div className="w-[1340px] h-[83px]">
          <Card className="w-full h-full rounded-[41.5px]" />
        </div>

        {/* Chat */}
        <div className="relative w-[1340px] h-[577px]">
          <Card className="w-full h-full rounded-[40px]" />

          {/* Header */}
          <div className="absolute top-0 left-0 w-full">
            <div className="flex items-center justify-center">
              <div
  onClick={() => navigate("/")}
  className="absolute top-4 left-4 bg-[#4866F6] w-[44px] h-[44px] rounded-full flex justify-center items-center cursor-pointer"
>
  <img src={Arrow} />
</div>

              <div className="absolute top-5 left-20">
                <p className="font-sf font-[590] text-[24px] text-[#3D3D3D]">
                  AI Chat Window
                </p>
              </div>

              <div className="absolute top-4 right-4">
                <Button
                  label="New Conversation +"
                />
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="absolute top-[70px] left-3 right-3 border-t border-gray-400"></div>

          {/* Body */}
          <div className="absolute top-[80px] left-0 w-full px-6">
            <div className="h-[360px] overflow-y-auto flex flex-col gap-6 pr-2">

              {messages.map((msg, i) => (
                <div key={i}>

                  {/* BOT */}
                  {msg.type === "bot" && (
                    <div className="flex gap-3 items-start ">

                      {/* AI Avatar */}
                      <div className="w-[50px] h-[50px] bg-blue-100 rounded-full flex items-center justify-center shrink-0">
                        <img src={AiImage} className="w-[33.34px] h-[30px] rounded-full" />
                      </div>

                      <div className="flex flex-col gap-2 ">

                        {/* Message bubble (auto width) */}
                        <div className="bg-gray-200 px-4 py-3 ounded-tl-[40px] rounded-tl-[30px] rounded-tr-[10px] rounded-br-[10px] rounded-bl-[0px]max-w-[520px] w-fit">
                          <p className="text-sm text-gray-700">{msg.text}</p>

                          {msg.data?.items?.length > 0 && (
                            <ul className="mt-2 text-xs list-disc pl-4 text-gray-600">
                              {msg.data.items.map((item, idx) => (
                                <li key={idx}>{item}</li>
                              ))}
                            </ul>
                          )}
                        </div>

                        {/* Icons + Time (auto align to content) */}
                        <div className="flex items-center justify-between w-full">

                          {/* Icons */}
                          <div className="flex items-center gap-[10px]">

                            <div className="w-[35px] h-[35px] bg-gray-200 rounded-full flex items-center justify-center">
                              <img src={SpeakerHigh} className="w-4 h-4" />
                            </div>

                            <div className="w-[35px] h-[35px] bg-gray-200 rounded-full flex items-center justify-center">
                              <img src={Copy} className="w-4 h-4" />
                            </div>

                            <div className="w-[35px] h-[35px] bg-gray-200 rounded-full flex items-center justify-center">
                              <img src={Save} className="w-4 h-4" />
                            </div>

                            <div className="w-[35px] h-[35px] bg-gray-200 rounded-full flex items-center justify-center">
                              <img src={Share} className="w-4 h-4" />
                            </div>

                          </div>

                          {/* Time */}
                          <p className="text-[10px] text-gray-400 ml-3">
                            {msg.time}
                          </p>

                        </div>

                      </div>
                    </div>
                  )}

                  {/* USER */}
                  {msg.type === "user" && (
                    <div className="flex justify-end items-end w-[690px] gap-1 p-1 ml-auto">

                      {/* Message */}
                      <div className="flex flex-col items-end gap-1">

                        {/* Bubble */}
                        <div className="bg-[#4866F6] text-white px-4 py-3 rounded-xl ounded-tl-[40px] rounded-tl-[10px] rounded-tr-[30px] rounded-br-[0px] rounded-bl-[10px] max-w-[520px]">
                          <p className="text-sm">{msg.text}</p>
                        </div>

                        {/* Time + Edit */}
                        <div className="flex items-center justify-between w-full">
                          <div className="w-[35px] h-[35px] bg-gray-200 rounded-full flex items-center justify-center">
                            <img src={Edit} alt="" className="w-4 h-4" />
                          </div>
                          <p className="text-[10px] text-gray-400 ml-3">{msg.time}</p>
                        </div>

                      </div>

                      {/* Avatar */}
                      <div className="relative w-[50px] h-[50.5px] bg-gray-200 rounded-full shrink-0">

                        {/* Head */}
                        <img
                          src={UserHead}
                          className="absolute w-[16.6px] h-[16.6px] top-[2px] left-[17px]"
                        />

                        {/* Body */}
                        <img
                          src={UserBody}
                          className="absolute w-[31.4px] h-[20.5px] top-[20px] left-[9px]"
                        />

                      </div>

                    </div>
                  )}

                </div>
              ))}

              <div ref={bottomRef} />
            </div>
          </div>

          {/* Footer */}
          <div className="absolute bottom-0 left-0 w-full p-4 flex items-center gap-4">
            <div className="h-[60px] w-[60px] bg-blue-100 rounded-md border-2 border-blue-500 flex items-center justify-center">
              <img className="h-[28px]" src={FileUpload} />
            </div>

            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              className="bg-blue-100 rounded-md border-2 border-blue-500 p-2 flex-1 h-[60px] outline-none"
              placeholder="Type Your Message Here...."
            />

            <div className="h-[60px] w-[60px] bg-blue-100 rounded-md border-2 border-[#4866F6] flex items-center justify-center">
              <img className="h-[28px]" src={Audio} />
            </div>

            <div
              onClick={handleSend}
              className="h-[60px] w-[60px] bg-[#4866F6] rounded-md flex items-center justify-center cursor-pointer"
            >
              <img className="h-[28px]" src={EnterFrame} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIConversation;