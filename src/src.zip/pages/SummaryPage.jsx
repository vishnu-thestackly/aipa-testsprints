import { useState } from "react";

const SummaryPage = () => {
  const [input, setInput] = useState("");
  const [summary, setSummary] = useState("");

  const handleSummarize = () => {
    // 🔁 Replace with real AI API later
    const short = input.slice(0, 100);
    setSummary(short + "...");
  };

  return (
    <div className="min-h-screen p-6 md:p-10 bg-gray-50">
      <h1 className="text-2xl md:text-3xl font-semibold mb-6">
        Summarize Content
      </h1>

      <div className="bg-white p-6 rounded-xl shadow-sm">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste your content..."
          className="w-full h-[150px] p-3 border rounded-lg"
        />

        <button
          onClick={handleSummarize}
          className="mt-4 px-6 py-2 bg-[#4866F6] text-white rounded-lg"
        >
          Summarize
        </button>

        {summary && (
          <div className="mt-6 p-4 bg-gray-100 rounded-lg">
            <p className="text-sm">{summary}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SummaryPage;