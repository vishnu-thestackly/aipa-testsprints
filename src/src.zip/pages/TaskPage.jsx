import { useState } from "react";

const TaskPage = () => {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (!task.trim()) return;
    setTasks([...tasks, task]);
    setTask("");
  };

  const deleteTask = (index) => {
    const updated = tasks.filter((_, i) => i !== index);
    setTasks(updated);
  };

  return (
    <div className="min-h-screen p-6 md:p-10 bg-gray-50">
      <h1 className="text-2xl md:text-3xl font-semibold mb-6">
        Task Manager
      </h1>

      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex gap-2">
          <input
            value={task}
            onChange={(e) => setTask(e.target.value)}
            placeholder="Enter a task..."
            className="flex-1 p-2 border rounded-lg"
          />

          <button
            onClick={addTask}
            className="px-4 bg-[#4866F6] text-white rounded-lg"
          >
            Add
          </button>
        </div>

        <ul className="mt-6 space-y-2">
          {tasks.map((t, i) => (
            <li
              key={i}
              className="flex justify-between items-center bg-gray-100 p-3 rounded-lg"
            >
              <span>{t}</span>

              <button
                onClick={() => deleteTask(i)}
                className="text-red-500 text-sm"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default TaskPage;