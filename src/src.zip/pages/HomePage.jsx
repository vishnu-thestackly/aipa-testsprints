import Header from "../components/homepage/Header";
import Hero from "../components/homepage/Hero";
import FeatureCards from "../components/homepage/FeatureCards";
import Footer from "../components/homepage/Footer";
import bgHome from "../assets/images/bghome.png";

const HomePage = () => {
  return (
<main className="relative h-screen overflow-hidden flex flex-col max-md:overflow-y-auto">      {/* Background */}
      <div
        className="fixed inset-0 bg-cover bg-center bg-no-repeat -z-10"
        style={{ backgroundImage: `url(${bgHome})` }}
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-white/20 -z-10"></div>

      {/* Content */}
      <div className="flex flex-col">

{/* HEADER */}
        <Header />

        {/* CENTER CONTENT */}
       <div className="flex flex-col">
          <div
            className="
              w-full mx-auto
              px-6 md:px-10
              max-w-[1200px]
              lg:max-w-[1400px]
              xl:max-w-[1600px]
            "
          >
            <Hero />
            <FeatureCards />
          </div>
        </div>

        {/* FOOTER */}
        <Footer />

      </div>
    </main>
  );
};

export default HomePage;