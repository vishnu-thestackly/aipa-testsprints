import { useNavigate } from "react-router-dom";

const FeatureCard = ({ title, desc, image, path }) => {
  const navigate = useNavigate();

  return (
    <div
      className="
  relative 
  w-full 
  h-full 
 min-h-[200px]
sm:min-h-[220px]
md:min-h-[240px]
xl:min-h-[260px]
  rounded-2xl overflow-hidden group
"
      style={{
        backgroundImage: `url(${image})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-black/10 to-transparent"></div>

      {/* Content */}
      <div className="relative z-10 p-4 sm:p-5 md:p-6 h-full flex flex-col justify-end text-white">

        <h3 className="text-[16px] sm:text-[17px] md:text-[18px] xl:text-[20px] font-semibold">
          {title}
        </h3>

        <div className="mt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-4">

          <p className="text-[13px] sm:text-[14px] md:text-[16px] leading-[20px] md:leading-[26px] max-w-full sm:max-w-[70%]">
            {desc}
          </p>

          <button
  onClick={() => navigate(path)}
  className="
    w-full 
    sm:w-[119px] 
    xl:w-[140px]
    h-[36px] 
    sm:h-[48px] 
    xl:h-[52px]
    rounded-[25px] 
    bg-[#4866F6] 
    text-[12px] 
    sm:text-[14px] 
    xl:text-[16px]
    flex items-center justify-center

    cursor-pointer   /* ✅ ADD THIS */
  "
>
  Explore Now
</button>
            

        </div>
      </div>
    </div>
  );
};

export default FeatureCard;