import FeatureCard from "./FeatureCard";

import askImg from "../../assets/images/card-ask.svg";
import taskImg from "../../assets/images/card-task.svg";
import summaryImg from "../../assets/images/card-summary.svg";

const FeatureCards = () => {
  const data = [
  {
    title: "Ask anything",
    desc: "Get instant answers and insights for anything you need.",
    image: askImg,
    path: "/ask",
  },
  {
    title: "Create a task",
    desc: "Easily create and manage tasks to stay organized.",
    image: taskImg,
    path: "/task",
  },
  {
    title: "Summarize content",
    desc: "Quickly turn long content into short, clear summaries.",
    image: summaryImg,
    path: "/summary",
  },
];
  return (
<section className="mt-[24px] md:mt-[32px] pb-[24px] md:pb-[32px]">

  <div className="
    grid
    grid-cols-1
    sm:grid-cols-2
    md:grid-cols-3
    gap-4 sm:gap-6 xl:gap-8
  ">
    
    {/* gap-10 md:gap-14 xl:gap-20  
     for gap between each card */}


    {data.map((item, i) => (
      <FeatureCard key={i} {...item} />
    ))}
    
  </div>

</section>
  );
};

export default FeatureCards;