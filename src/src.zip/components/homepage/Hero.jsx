import { useNavigate } from "react-router-dom";

const Hero = () => {
  const navigate = useNavigate();

  return (
    <section className="text-center text-white">

     <div className="
  mt-8   /* 👈 pushes entire section up */
  pt-[40px] sm:pt-[60px] md:pt-[70px] xl:pt-[60px]
  max-w-[90%] md:max-w-[864px] xl:max-w-[1000px]
  mx-auto
">

        {/* Subtitle */}
        <p className="font-mont text-[18px] sm:text-[22px] md:text-[28px] xl:text-[30px] 2xl:text-[32px] font-medium text-white/80">
          Welcome to your
        </p>

        {/* Title */}
        <h1
  className="
    font-mont mt-2 font-bold leading-[1] text-white mx-auto
    text-[32px] sm:text-[42px] md:text-[56px] xl:text-[64px] 2xl:text-[72px]
    max-w-[90%] md:max-w-[680px] xl:max-w-[820px] 2xl:max-w-[900px]
  "
>
  AI Personal Assistant
</h1>

        {/* Description */}
        <p className="
          mt-6 tracking-[0.02em] text-[#FFFFFFCC] mx-auto
          text-[14px] sm:text-[16px] md:text-[18px] xl:text-[20px]
          leading-[24px] md:leading-[30px] xl:leading-[32px]
          max-w-[95%] md:max-w-[820px] xl:max-w-[900px] 2xl:max-w-[1000px]
        ">
          AI Personal Assistant is a platform to create, manage, and optimize daily activities using the power of AI.
          Use it to generate content and efficiently handle meetings, tasks, and reminders.
        </p>

        {/* Button */}
        <button
  onClick={() => navigate("/conversation")}
  className="
    mt-8 mx-auto rounded-[100px] border-2 border-[#4866F6]
    bg-white/80 backdrop-blur-sm text-[#4866F6] font-medium
    flex items-center justify-center 
    hover:bg-[#4866F6] hover:text-white transition

    cursor-pointer   /* ✅ ADD THIS */

    w-[85%] sm:w-[260px] md:w-[300px] xl:w-[340px] 2xl:w-[380px]
    h-[44px] md:h-[48px] xl:h-[52px] 2xl:h-[56px]
    text-[14px] md:text-[16px] xl:text-[18px]
  "
>
  Start New Conversation
</button>

      </div>
    </section>
  );
};

export default Hero;