import { useNavigate } from "react-router-dom";

const Footer = () => {
  const navigate = useNavigate();

  return (
    <footer className="w-full pt-[20px] pb-[20px] shrink-0">

      <div
        className="
          w-full mx-auto
          px-6 md:px-10
          max-w-[1200px]
          lg:max-w-[1400px]
          xl:max-w-[1600px]
        "
      >
        <div className="
          grid
          grid-cols-1
          sm:grid-cols-2
          md:grid-cols-3
          gap-4 sm:gap-6 xl:gap-8
          items-center
        ">

          <p className="
            text-[#8D97A9]
            text-[16px] sm:text-[18px]
            font-bold
            justify-self-start
          ">
            © All Rights Reserved
          </p>

          <div className="hidden md:block"></div>

          <p
            onClick={() => navigate("/faq")}
            className="
              text-[#8D97A9]
              text-[16px] sm:text-[18px]
              font-bold
              cursor-pointer hover:underline
              justify-self-end
            "
          >
            Help | FAQ
          </p>

        </div>
      </div>

    </footer>
  );
};

export default Footer;