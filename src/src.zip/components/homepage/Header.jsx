import { useState, useEffect, useRef } from "react";

import logo from "../../assets/images/Logo.svg";
import Lang from "../../assets/images/Language.svg";
import Notification from "../../assets/images/Notification.svg";
import Mode from "../../assets/images/Darkmode.svg";

const Header = () => {
  const [activeBtn, setActiveBtn] = useState("");
  const [showLang, setShowLang] = useState(false);
  const [selectedLang, setSelectedLang] = useState("English");

  const wrapperRef = useRef(null);

  const languages = ["English", "Spanish", "German", "French", "Hindi", "Tamil"];

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setActiveBtn("");
        setShowLang(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  // ICON BUTTON
  const iconStyle = (name) =>
    `w-12 h-12 rounded-full flex items-center justify-center transition cursor-pointer group
    ${
      activeBtn === name
        ? "bg-blue-500"
        : "bg-[#eef1ff] hover:bg-blue-500"
    }`;

  // ICON IMAGE
  const imgStyle = (name) =>
    `w-7 h-7 transition ${
      activeBtn === name
        ? "invert brightness-0"
        : "invert-0 group-hover:invert group-hover:brightness-0"
    }`;

  return (
    <div
      className="w-full flex flex-col items-center mt-12 relative"
      ref={wrapperRef}
    >
      {/* HEADER */}
      <div className="w-full px-4">
        <div className="mx-auto max-w-[80%] bg-white rounded-full px-10 py-4 flex items-center justify-between shadow-lg">

          {/* LEFT */}
          <div className="flex items-center gap-4">
            <img src={logo} alt="Logo" className="h-14" />
            <div className="hidden sm:block border-l h-12"></div>
          </div>

          {/* RIGHT */}
          <div className="flex items-center gap-4 relative">

            {/* ICONS */}
            <div className="flex gap-3">
              <button
                className={iconStyle("lang")}
                onClick={() => {
                  setActiveBtn("lang");
                  setShowLang(!showLang);
                }}
              >
                <img src={Lang} alt="lang" className={imgStyle("lang")} />
              </button>

              <button
                className={iconStyle("notify")}
                onClick={() => {
                  setActiveBtn("notify");
                  setShowLang(false);
                }}
              >
                <img src={Notification} className={imgStyle("notify")} />
              </button>

              <button
                className={iconStyle("mode")}
                onClick={() => {
                  setActiveBtn("mode");
                  setShowLang(false);
                }}
              >
                <img src={Mode} className={imgStyle("mode")} />
              </button>
            </div>

            {/* AUTH BUTTONS */}
            <div className="flex gap-3 ml-3">
              <button className="px-8 h-12 text-base rounded-full bg-blue-500 text-white hover:bg-blue-600 transition">
                Log In
              </button>

              <button className="px-8 h-12 text-base rounded-full bg-blue-500 text-white hover:bg-blue-600 transition">
                Sign Up
              </button>
            </div>

            {/* 🔥 LANGUAGE DROPDOWN */}
            {showLang && (
              <div className="absolute top-[75px] left-0 w-full flex justify-center z-50">

                <div
                  className="
                    bg-white rounded-full px-2 py-1 shadow-lg
                    flex gap-4
                    overflow-x-auto
                    w-full max-w-[1500px]

                    snap-x snap-mandatory
                    scroll-smooth

                    scrollbar-hide

                    touch-pan-x
                    select-none
                  cursor-pointer
                  "
                >
                  {languages.map((item, index) => (
                    <button
                      key={index}
                      id={`lang-${index}`}
                      onClick={() => {
                        setSelectedLang(item);

                        const el = document.getElementById(`lang-${index}`);
                        el?.scrollIntoView({
                          behavior: "smooth",
                          inline: "center",
                        });
                      }}
                      className={`px-10 py-2 rounded-full text-sm whitespace-nowrap transition snap-center
                      ${
                        selectedLang === item
                          ? "bg-blue-500 text-white"
                          : "bg-[#eef1ff] text-gray-700 hover:bg-blue-500 hover:text-white"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>

              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;